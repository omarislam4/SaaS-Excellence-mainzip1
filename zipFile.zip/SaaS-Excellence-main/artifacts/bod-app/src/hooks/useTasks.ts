import { useState, useEffect } from "react";
import { collection, onSnapshot, query, where, orderBy, Timestamp } from "firebase/firestore";
import { db } from "../firebase";

function toDate(val: unknown): Date | null {
  if (!val) return null;
  if (val instanceof Timestamp) return val.toDate();
  if (val instanceof Date) return val;
  if (typeof val === "string" || typeof val === "number") {
    const d = new Date(val);
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
}

export type TaskStatus = "todo" | "in-progress" | "review" | "done" | "blocked";
export type TaskPriority = "low" | "medium" | "high" | "urgent";

export interface Task {
  id: string;
  spaceId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assigneeIds: string[];
  senderId: string;
  deadline: Date | null;
  estimatedHours: number;
  progress: number;
  createdAt: Date;
  createdBy: string;
  completedAt: Date | null;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  detail: string;
  createdAt: Date;
}

function mapTask(doc: { id: string; data: () => Record<string, unknown> }): Task {
  const d = doc.data();
  return {
    title: "",
    description: "",
    status: "todo",
    priority: "medium",
    assigneeIds: [],
    senderId: "",
    spaceId: "",
    estimatedHours: 0,
    progress: 0,
    createdBy: "",
    ...d,
    id: doc.id,
    deadline: toDate(d.deadline),
    createdAt: toDate(d.createdAt) ?? new Date(),
    completedAt: toDate(d.completedAt),
  } as Task;
}

export const useTasks = (spaceId?: string) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!spaceId) {
      setLoading(false);
      return;
    }

    // Use only where() without compound orderBy to avoid needing a composite index.
    // Sort client-side instead.
    const q = query(collection(db, "tasks"), where("spaceId", "==", spaceId));

    const unsub = onSnapshot(q, (snap) => {
      const data = snap.docs
        .map(mapTask)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      setTasks(data);
      setLoading(false);
    });

    return () => unsub();
  }, [spaceId]);

  return { tasks, loading };
};

export const useAllTasks = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // orderBy on a single field (no where clause) doesn't need a composite index.
    const q = query(collection(db, "tasks"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setTasks(snap.docs.map(mapTask));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  return { tasks, loading };
};
